let pokemonList = [
    
    {
        id: 0o0011,
        name: 'Jigglypuff',
        hp: 115,
        attack: 45,
        defense: 20,
        spAttack: 45,
        spDefense: 25,
        speed: 20,
        height: 0.5,
        types: ['fairy normal'],
    
    },
    {
        id: 0o0022,
        name: 'Butterfree',
        hp: 60,
        attack: 45,
        defense: 50,
        spAttack: 90,
        spDefense: 80,
        speed: 70,
        height: 1.1,
        types: ['Bug Flying'],
        
    },
    {
        id: 0o0033,
        name:'Raichu',
        hp: 60,
        attack: 90,
        defense: 55,
        spAttack: 90,
        spDefense: 80,
        speed: 110,
        height: 0.8,
        types: ['Electric'], 
    },
];