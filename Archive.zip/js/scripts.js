<html>
    <head> 
        <meta name="color-scheme" content="light dark"></meta>
    </head>
    <body>
        <pre style="word-wrap: break-word; white-space: pre-wrap;">alert("Hello World"); let 
        favoritefood = "Pasta"; document.write(favoritefood);</pre>
    </body>
</html>