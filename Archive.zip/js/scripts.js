alert("Hello World"); 
let favoritefood = "Pasta"; 
document.write(favoritefood);